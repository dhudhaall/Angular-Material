import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filters-listings',
  templateUrl: './filters-listings.component.html',
  styleUrls: ['./filters-listings.component.scss']
})
export class FiltersListingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
