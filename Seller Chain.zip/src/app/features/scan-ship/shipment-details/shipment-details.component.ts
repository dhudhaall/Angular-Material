import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-details',
  templateUrl: './shipment-details.component.html',
  styleUrls: ['./shipment-details.component.scss']
})
export class ShipmentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
