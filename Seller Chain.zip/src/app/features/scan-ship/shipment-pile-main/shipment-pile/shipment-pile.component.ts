import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-shipment-pile',
  templateUrl: './shipment-pile.component.html',
  styleUrls: ['./shipment-pile.component.scss']
})
export class ShipmentPileComponent implements OnInit {
 showStep2 = false;
  constructor() { }

  ngOnInit(): void {
  }

  

}
