import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scanship-dashbord-main',
  templateUrl: './scanship-dashbord-main.component.html',
  styleUrls: ['./scanship-dashbord-main.component.scss']
})
export class ScanshipDashbordMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
