import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-add-item-main',
  templateUrl: './new-add-item-main.component.html',
  styleUrls: ['./new-add-item-main.component.scss']
})
export class NewAddItemMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
