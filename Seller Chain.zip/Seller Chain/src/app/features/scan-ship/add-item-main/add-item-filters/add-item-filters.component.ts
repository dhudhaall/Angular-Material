import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-item-filters',
  templateUrl: './add-item-filters.component.html',
  styleUrls: ['./add-item-filters.component.scss']
})
export class AddItemFiltersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
