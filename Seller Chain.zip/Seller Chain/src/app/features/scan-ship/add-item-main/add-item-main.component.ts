import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-item-main',
  templateUrl: './add-item-main.component.html',
  styleUrls: ['./add-item-main.component.scss']
})
export class AddItemMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
