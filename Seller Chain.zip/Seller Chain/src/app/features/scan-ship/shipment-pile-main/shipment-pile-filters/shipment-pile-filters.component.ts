import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-pile-filters',
  templateUrl: './shipment-pile-filters.component.html',
  styleUrls: ['./shipment-pile-filters.component.scss']
})
export class ShipmentPileFiltersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
