import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-pile-main',
  templateUrl: './shipment-pile-main.component.html',
  styleUrls: ['./shipment-pile-main.component.scss']
})
export class ShipmentPileMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
