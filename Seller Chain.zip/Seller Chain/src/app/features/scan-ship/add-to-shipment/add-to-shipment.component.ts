import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-to-shipment',
  templateUrl: './add-to-shipment.component.html',
  styleUrls: ['./add-to-shipment.component.scss']
})
export class AddToShipmentComponent implements OnInit {
  isEditable = true;
  constructor() { }

  ngOnInit(): void {
  }

}
