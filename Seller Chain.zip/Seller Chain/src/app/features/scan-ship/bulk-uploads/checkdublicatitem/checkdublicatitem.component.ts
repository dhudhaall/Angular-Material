import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkdublicatitem',
  templateUrl: './checkdublicatitem.component.html',
  styleUrls: ['./checkdublicatitem.component.scss']
})
export class CheckdublicatitemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
