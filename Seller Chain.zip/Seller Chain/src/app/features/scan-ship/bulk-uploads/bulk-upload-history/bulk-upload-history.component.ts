import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bulk-upload-history',
  templateUrl: './bulk-upload-history.component.html',
  styleUrls: ['./bulk-upload-history.component.scss']
})
export class BulkUploadHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
