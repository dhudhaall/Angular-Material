import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bulk-item-detail',
  templateUrl: './bulk-item-detail.component.html',
  styleUrls: ['./bulk-item-detail.component.scss']
})
export class BulkItemDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
