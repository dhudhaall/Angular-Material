import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-submit-bulk-upload-popup',
  templateUrl: './submit-bulk-upload-popup.component.html',
  styleUrls: ['./submit-bulk-upload-popup.component.scss']
})
export class SubmitBulkUploadPopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
