import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-details-main',
  templateUrl: './shipment-details-main.component.html',
  styleUrls: ['./shipment-details-main.component.scss']
})
export class ShipmentDetailsMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
