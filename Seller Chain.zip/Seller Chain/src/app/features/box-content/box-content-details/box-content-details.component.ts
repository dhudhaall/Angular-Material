import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-box-content-details',
  templateUrl: './box-content-details.component.html',
  styleUrls: ['./box-content-details.component.scss']
})
export class BoxContentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
