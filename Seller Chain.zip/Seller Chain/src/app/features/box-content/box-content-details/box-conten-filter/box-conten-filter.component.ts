import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-box-conten-filter',
  templateUrl: './box-conten-filter.component.html',
  styleUrls: ['./box-conten-filter.component.scss']
})
export class BoxContenFilterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
