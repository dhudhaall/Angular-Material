import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-empty-box-popup',
  templateUrl: './add-empty-box-popup.component.html',
  styleUrls: ['./add-empty-box-popup.component.scss']
})
export class AddEmptyBoxPopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
