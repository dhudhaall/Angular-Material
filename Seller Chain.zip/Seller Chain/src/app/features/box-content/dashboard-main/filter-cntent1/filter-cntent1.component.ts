import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-cntent1',
  templateUrl: './filter-cntent1.component.html',
  styleUrls: ['./filter-cntent1.component.scss']
})
export class FilterCntent1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
