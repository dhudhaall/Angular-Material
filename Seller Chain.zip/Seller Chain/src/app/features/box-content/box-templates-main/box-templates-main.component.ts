import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-box-templates-main',
  templateUrl: './box-templates-main.component.html',
  styleUrls: ['./box-templates-main.component.scss']
})
export class BoxTemplatesMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
