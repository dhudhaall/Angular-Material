import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-templats-filter',
  templateUrl: './templats-filter.component.html',
  styleUrls: ['./templats-filter.component.scss']
})
export class TemplatsFilterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
