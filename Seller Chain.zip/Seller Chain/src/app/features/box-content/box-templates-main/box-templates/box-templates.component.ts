import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-box-templates',
  templateUrl: './box-templates.component.html',
  styleUrls: ['./box-templates.component.scss']
})
export class BoxTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
