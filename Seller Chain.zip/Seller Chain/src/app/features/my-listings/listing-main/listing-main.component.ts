import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listing-main',
  templateUrl: './listing-main.component.html',
  styleUrls: ['./listing-main.component.scss']
})
export class ListingMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
