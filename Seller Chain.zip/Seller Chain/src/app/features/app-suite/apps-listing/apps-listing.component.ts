import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apps-listing',
  templateUrl: './apps-listing.component.html',
  styleUrls: ['./apps-listing.component.scss']
})
export class AppsListingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  changeLabelText() {

  }

}
