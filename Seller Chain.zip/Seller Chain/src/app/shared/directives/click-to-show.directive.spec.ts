import { ClickToShowDirective } from './click-to-show.directive';

describe('ClickToShowDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickToShowDirective();
    expect(directive).toBeTruthy();
  });
});
